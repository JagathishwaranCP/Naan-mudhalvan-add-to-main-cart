import Img1 from "./img/img1.png";
import Img2 from "./img/img2.png";
import Img3 from "./img/img3.png";
const Data = {
  productData: [
    {
      id: 1,
      img: Img1,
      title: "Juicy Grapes",
      desc: "",
      price: 46,
    },
    {
        id: 2,
        img: Img2,
        title: "Red Watermelon",
        desc: "",
        price: 56,
      },
      {
        id: 3,
        img: Img3,
        title: "Juicy Orange",
        desc: "",
        price: 78,
      },
  ],
};
export default Data;